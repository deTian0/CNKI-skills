# 🚀 快速启动指南

## 一、安装步骤（5分钟）

### Windows用户

双击运行安装脚本：
```
install.bat
```

### Linux/Mac用户

```bash
chmod +x install.sh
./install.sh
```

### 手动安装（可选）

如果脚本无法运行，请手动执行：

1. **安装依赖**
```bash
pip install playwright
playwright install chromium
```

2. **复制Skill文件**
```bash
# 复制整个项目到Claude Skills目录
cp -r cnki-downloader-skill ~/.claude/skills/
```

3. **重启Claude Code**

---

## 二、立即开始使用

### 方式1：直接对话（推荐）

重启Claude Code后，直接对话：

```
👤 用户: 帮我下载3篇跟"人工智能"相关的学位论文到 D:\papers\

🤖 Claude: 好的，我来帮您下载论文。
         （自动执行下载任务...）
```

### 方式2：使用Python代码

如果你想自己编程调用：

```python
# 在Claude Code中运行
from src.main import get_skill

skill = get_skill()
result = await skill.download_papers(
    "帮我下载3篇跟'人工智能'相关的学位论文到 D:\\papers\\"
)
print(result)
```

---

## 三、使用示例

### 示例1：下载期刊论文

```
下载10篇关于"机器学习"的学术期刊到 C:\Research\ML\
```

### 示例2：下载会议论文

```
帮我下20个会议论文，主题是深度学习，保存到 ~/papers/
```

### 示例3：下载专利

```
下载5篇专利，关键词是区块链，到 D:\patents\
```

### 示例4：下载学位论文

```
下载十篇硕博论文到 D:\thesis\
```

---

## 四、支持的文献类型

| 类型 | 可用别名 |
|------|---------|
| 学术期刊 | 期刊、期刊文章、journal |
| 学位论文 | 学位、硕博论文、thesis |
| 会议 | 会议论文、conference |
| 报纸 | 报纸文章、newspaper |
| 年鉴 | 统计年鉴、yearbook |
| 专利 | patent |
| 标准 | standard |
| 成果 | 科技成果 |
| 辑刊 | 学术辑刊 |
| 图书 | 图书章节、book |
| 文库 | 知网文库 |

---

## 五、常见问题

### Q1: 提示"无法定位搜索框"？

**解决方法：**
1. 检查网络连接
2. 尝试手动访问 https://www.cnki.net/
3. 确保Playwright和Chromium已安装

### Q2: 下载速度很慢？

**解决方法：**
- 检查网络速度
- 减少并发数配置
- 避开高峰时段

### Q3: 部分论文下载失败？

**解决方法：**
- 确保已登录CNKI账号
- 检查账号权限
- 付费论文会自动跳过

### Q4: 如何调整并发数？

编辑配置文件：`~/.cnki_downloader/config.json`

```json
{
  "download_settings": {
    "max_concurrent": 5  // 改为你想要的并发数
  }
}
```

---

## 六、配置文件位置

| 系统 | 配置文件位置 |
|------|-------------|
| Windows | `%USERPROFILE%\.cnki_downloader\config.json` |
| Linux/Mac | `~/.cnki_downloader/config.json` |

### 可配置项

```json
{
  "download_settings": {
    "max_concurrent": 3,      // 最大并发下载数
    "timeout": 30000,          // 超时时间（毫秒）
    "retry_times": 2           // 重试次数
  },
  "browser_settings": {
    "headless": false,         // 是否无头模式（true=不显示浏览器）
    "slow_mo": 100             // 操作延迟（毫秒）
  },
  "file_settings": {
    "sanitize_filename": true,  // 清理文件名特殊字符
    "max_filename_length": 200  // 最大文件名长度
  }
}
```

---

## 七、目录结构

安装后的目录结构：

```
~/.claude/skills/cnki-downloader/
├── src/                        # 源代码
│   ├── __init__.py
│   ├── main.py                 # 主入口
│   ├── parser.py               # 输入解析器
│   ├── cnki_browser.py         # 浏览器操作
│   ├── downloader.py           # 下载器
│   ├── models.py               # 数据模型
│   ├── config.py               # 配置管理
│   └── utils.py                # 工具函数
├── skill.json                  # Skill配置
├── skill_prompt.md             # Skill说明
├── README.md                   # 详细文档
└── CNKI论文下载Skill需求文档.md  # 需求文档
```

---

## 八、测试安装

### 快速测试

在Claude Code中运行：

```python
# 测试解析器
from src.parser import InputParser

parser = InputParser()
result = parser.parse("下载5篇关于AI的论文到 D:\\test\\")
print(f"关键词: {result.keyword}")
print(f"数量: {result.count}")
print(f"类型: {result.doc_type}")
print(f"目录: {result.save_dir}")
```

### 完整测试

```
👤 用户: 帮我下载1篇测试论文到 D:\test\

🤖 Claude: （执行下载任务）
         ...
```

---

## 九、卸载

如果需要卸载：

```bash
# Linux/Mac
rm -rf ~/.claude/skills/cnki-downloader

# Windows
rmdir /s %USERPROFILE%\.claude\skills\cnki-downloader
```

---

## 十、获取帮助

- 📖 查看完整文档：`README.md`
- 📋 查看需求文档：`CNKI论文下载Skill需求文档.md`
- 💬 提交问题：GitHub Issues

---

**开始使用吧！🎉**

如有任何问题，请查看完整文档或提交Issue。
